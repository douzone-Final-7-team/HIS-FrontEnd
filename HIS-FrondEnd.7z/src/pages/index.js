import React from 'react'
import PagiNavigation from './PagiNavigation';

const index = () => {
  return (
    <div>
      <PagiNavigation />
    </div>
  )
}

export default index;
