import React from 'react';
import './dischargeDue.scss';

const DischargeDue = () => {

    return (
        <div className='discharge-Due-wapper'>
            <div className='discharge-Due-big-square'>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                <div className='discharge-Due-small-square'>
                    <ul>
                        <li>
                            <p className='due-position'>
                                <span className='a'>김민욱</span>
                                <span className='b'>M/26</span>
                                <span className='c'>970311-1xxxxxx</span>
                                <span className='d'>14(월)</span>
                                <span className='e'>15:00</span>
                                <span className='f'>501호 1병상</span>
                                <input className='g'type='button' value = "퇴실완료"/>
                            </p>
                        </li>
                    </ul>
                </div>
                

                

            </div>
        </div>
    )
}

export default DischargeDue