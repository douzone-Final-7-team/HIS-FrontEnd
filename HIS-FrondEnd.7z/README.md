# HIS-Project-Front-Repository

더존비즈온 채용연계 훈련과정 파이널 프로젝트


### 🛠 Using Libraries

- node-sass
- react-router-dom
- redux react-redux
- redux-toolkit
- axios

<br> 

### 개발목표

<br> 

### 서비스 내용

<br> 

### 프로젝트 진행

<br> 

### 개발내용

Lorem Ipsum is simply dummy text of
the printing and typesetting industry. 

Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and scrambled it to make a type specimen book. 

